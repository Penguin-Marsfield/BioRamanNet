import torch
import torch.nn as nn
from AdaptiveConv1d import AdaptiveConv1d

class RNNWithSelfAttention(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(RNNWithSelfAttention, self).__init__()
        self.hidden_size = hidden_size

        # AdaptiveConv
        self.adc = AdaptiveConv1d(1, 1, 3)
        self.relu = nn.ReLU()

        # RNN
        self.layers = 1
        self.rnn = nn.RNN(input_size, hidden_size, batch_first=True)

        # Dropout
        self.dropout = nn.Dropout(p=0.5)

        # Batch normalization
        self.batchnorm = nn.BatchNorm1d(hidden_size)

        # Self-Attention
        self.attn = nn.Linear(hidden_size, hidden_size)
        self.query = nn.Parameter(torch.randn(1, hidden_size))  # Learnable query vector
        self.softmax = nn.Softmax(dim=1)

        # Fully connected layer
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        # Adaptive Convolution
        x = self.relu(self.adc(x))

        # RNN
        h0 = torch.zeros(self.layers, x.size(0), self.hidden_size).to(x.device)
        rnn_output, _ = self.rnn(x, h0)
        rnn_output = self.batchnorm(rnn_output.transpose(1, 2)).transpose(1, 2)
        rnn_output = self.dropout(rnn_output)

        # Self-Attention
        query = self.query.expand(rnn_output.size(0), -1).unsqueeze(1)  # Expand query for batch
        attn_weights = torch.bmm(query, self.attn(rnn_output).transpose(1, 2))  # Attention scores
        attn_weights = self.softmax(attn_weights)
        attn_output = torch.bmm(attn_weights, rnn_output)

        # Fully connected layer
        output = self.fc(attn_output.squeeze(1))
        return output
