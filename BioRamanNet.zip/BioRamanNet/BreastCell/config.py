# 5 cell
ORDER = [0, 1, 2, 3, 4]

CELLS = {}
CELLS[0] = "T47D"
CELLS[1] = "BT474"
CELLS[2] = "SK-BR-3"
CELLS[3] = "MDA-MB-231"
CELLS[4] = "MCF-10A"
