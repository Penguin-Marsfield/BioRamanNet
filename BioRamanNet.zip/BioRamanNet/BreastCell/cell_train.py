import numpy as np
from AdaptiveResNet import ResNet
import torch
from datasets import spectral_dataloader
from training import run_epoch
from torch import optim
import matplotlib.pyplot as plt
import os
from time import time

if __name__ == '__main__':
    X_fn = './data/X_train.npy'
    y_fn = './data/y_train.npy'
    X = np.load(X_fn)
    y = np.load(y_fn)
    print(X.shape, y.shape)

    # 打开结果文件
    with open('results.txt', 'w') as f:
        f.write("Run\tTrain Time\tBest Epoch\tTrain Acc\tVal Acc\n")

    # 参数设置
    layers = 2
    hidden_size = 64
    block_size = 2
    hidden_sizes = [hidden_size] * layers
    num_blocks = [block_size] * layers
    input_dim = 2000
    in_channels = 64
    n_classes = 5
    os.environ['CUDA_VISIBLE_DEVICES'] = '{}'.format(0)
    cuda = torch.cuda.is_available()

    # 运行5次独立训练
    for run in range(5):
        t00 = time()
        print(f"\nStarting run {run + 1}/5")
        cnn = ResNet(hidden_sizes, num_blocks, input_dim=input_dim, in_channels=in_channels, n_classes=n_classes)
        if cuda: cnn.cuda()

        p_val = 0.2
        n_val = int(831 * p_val)
        idx_tr = list(range(831))
        np.random.shuffle(idx_tr)
        idx_val = idx_tr[:n_val]
        idx_tr = idx_tr[n_val:]

        # Train
        epochs = 30
        batch_size = 5
        t0 = time()
        # Set up Adam optimizer
        optimizer = optim.Adamax(cnn.parameters(), lr=1e-4, betas=(0.5, 0.999))
        # Set up dataloaders
        dl_tr = spectral_dataloader(X, y, idxs=idx_tr,
                                    batch_size=batch_size, shuffle=True)
        dl_val = spectral_dataloader(X, y, idxs=idx_val,
                                     batch_size=batch_size, shuffle=True)

        # Prepare lists to store metrics
        train_accuracies = []
        train_losses = []
        val_accuracies = []
        val_losses = []

        # train for first fold
        best_val = 0
        model_save_path = f"BioRamanNet_cell_trained_model_run{run + 1}.ckpt"
        no_improvement = 0
        max_no_improvement = 10
        print('Starting train!')
        for epoch in range(epochs):
            print(' Epoch {}: {:0.2f}s'.format(epoch + 1, time() - t0))
            # Train
            acc_tr, loss_tr = run_epoch(epoch, cnn, dl_tr, cuda,
                                        training=True, optimizer=optimizer)
            print('  Train acc: {:0.2f}'.format(acc_tr))
            # Val
            acc_val, loss_val = run_epoch(epoch, cnn, dl_val, cuda,
                                          training=False, optimizer=optimizer)
            print('  Val acc  : {:0.2f}'.format(acc_val))

            # Store metrics
            train_accuracies.append(acc_tr)
            train_losses.append(loss_tr)
            val_accuracies.append(acc_val)
            val_losses.append(loss_val)

            # Check performance for early stopping
            if acc_val > best_val:
                best_val = acc_val
                best_epoch = epoch

                # save best model
                torch.save(cnn.state_dict(), model_save_path)
                print(f"New best model saved at epoch {epoch + 1} with val acc: {acc_val:.2f}")

            if acc_val < best_val:
                no_improvement += 1
            else:
                no_improvement = 0

            if no_improvement >= max_no_improvement:
                print('Finished after {} epochs!'.format(epoch + 1))
                break

        # 记录训练时间
        train_time = time() - t00

        # 将结果写入文件
        with open('results.txt', 'a') as f:
            f.write(
                f"{run + 1}\t{train_time:.2f}\t{best_epoch + 1}\t{train_accuracies[best_epoch]:.4f}\t{val_accuracies[best_epoch]:.4f}\n")

        print(f"\nRun {run + 1} completed in: {train_time:.2f}s")
        print(f"Best validation accuracy: {best_val:.4f}")

        # Plotting
        epochs_range = range(1, len(train_accuracies) + 1)
        plt.figure(figsize=(14, 5))

        # Plot accuracy
        plt.subplot(1, 2, 1)
        plt.plot(epochs_range, train_accuracies, label='Train Accuracy')
        plt.plot(epochs_range, val_accuracies, label='Validation Accuracy')
        plt.xlabel('Epochs')
        plt.ylabel('Accuracy')
        plt.legend(loc='lower right')
        plt.title(f'Run {run + 1} Accuracy vs. Epochs')

        # Plot loss
        plt.subplot(1, 2, 2)
        plt.plot(epochs_range, train_losses, label='Train Loss')
        plt.plot(epochs_range, val_losses, label='Validation Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.legend(loc='upper right')
        plt.title(f'Run {run + 1} Loss vs. Epochs')

        plt.savefig(f'training_metrics_run{run + 1}.png')
        plt.close()

    print('\nAll runs completed!')