import numpy as np
from AdaptiveResNet import ResNet
import torch
from datasets import spectral_dataloader
from training import run_epoch
from torch import optim
from training import get_predictions
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt
from config import ORDER, CELLS
import os
from time import time
import pandas as pd


def evaluate_model(model, X, y, cuda, model_name=""):
    """
    评估单个模型在测试集上的性能

    参数:
    model: 已加载权重的模型
    X: 测试集特征
    y: 测试集真实标签
    cuda: 是否使用GPU
    model_name: 模型名称（用于输出）

    返回:
    dict: 包含各种评估指标的字典
    """
    # 创建测试集数据加载器
    test_idxs = list(range(len(X)))
    dl_test = spectral_dataloader(X, y, idxs=test_idxs, batch_size=5, shuffle=False)

    # 获取预测结果
    y_hat = get_predictions(model, dl_test, cuda)

    # 计算各种指标
    accuracy = (y_hat == y).mean()
    precision = precision_score(y, y_hat, average='macro', zero_division=0)
    recall = recall_score(y, y_hat, average='macro', zero_division=0)
    f1 = f1_score(y, y_hat, average='macro', zero_division=0)

    # 生成混淆矩阵
    cm = confusion_matrix(y, y_hat, labels=ORDER)

    # 生成详细分类报告
    report = classification_report(y, y_hat, labels=ORDER, target_names=[CELLS[i] for i in ORDER], output_dict=True)

    results = {
        'model_name': model_name,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'confusion_matrix': cm,
        'predictions': y_hat,
        'classification_report': report
    }

    return results


def plot_confusion_matrix(cm, labels, title, filename):
    """
    绘制并保存混淆矩阵

    参数:
    cm: 混淆矩阵
    labels: 类别标签
    title: 图标题
    filename: 保存文件名
    """
    plt.figure(figsize=(10, 8))

    # 将混淆矩阵转换为百分比
    cm_percent = 100 * cm / cm.sum(axis=1)[:, np.newaxis]

    # 绘制热图
    ax = sns.heatmap(cm_percent, annot=True, cmap='YlGnBu', fmt='0.1f',
                     xticklabels=labels, yticklabels=labels)

    # 设置标题和标签
    plt.title(title, fontsize=16, pad=20)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.ylabel('True Label', fontsize=12)

    # 将x轴标签放在顶部
    ax.xaxis.tick_top()
    ax.xaxis.set_label_position('top')

    # 调整布局并保存
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()

    print(f"Confusion matrix saved as: {filename}")


if __name__ == '__main__':
    t00 = time()

    # 加载测试数据
    X_fn = './data/X_test.npy'
    y_fn = './data/y_test.npy'
    X = np.load(X_fn)
    y = np.load(y_fn)
    print(f"Test data shape: {X.shape}, {y.shape}")

    # 模型参数（需与训练时一致）
    layers = 2
    hidden_size = 64
    block_size = 2
    hidden_sizes = [hidden_size] * layers
    num_blocks = [block_size] * layers
    input_dim = 2000
    in_channels = 64
    n_classes = 5
    os.environ['CUDA_VISIBLE_DEVICES'] = '{}'.format(0)
    cuda = torch.cuda.is_available()

    # 模型权重文件列表
    model_paths = [f"BioRamanNet_cell_trained_model_run{i + 1}.ckpt" for i in range(5)]

    # 检查模型文件是否存在
    for path in model_paths:
        if not os.path.exists(path):
            print(f"Warning: Model file {path} not found!")

    # 存储所有模型的结果
    all_results = []

    print("Starting evaluation of 5 models...")
    print("=" * 60)

    for i, model_path in enumerate(model_paths):
        if not os.path.exists(model_path):
            print(f"Skipping {model_path} - file not found")
            continue

        print(f"\nEvaluating model {i + 1}/5: {model_path}")

        # 初始化模型
        model = ResNet(hidden_sizes, num_blocks, input_dim=input_dim,
                       in_channels=in_channels, n_classes=n_classes)

        # 加载权重
        model.load_state_dict(torch.load(model_path, map_location=lambda storage, loc: storage))
        if cuda:
            model.cuda()

        # 评估模型
        results = evaluate_model(model, X, y, cuda, model_name=f"Run_{i + 1}")
        all_results.append(results)

        # 打印当前模型结果
        print(f"Model {i + 1} Results:")
        print(f"  Accuracy:  {results['accuracy']:.4f}")
        print(f"  Precision: {results['precision']:.4f}")
        print(f"  Recall:    {results['recall']:.4f}")
        print(f"  F1-Score:  {results['f1_score']:.4f}")

        # 保存当前模型的混淆矩阵
        labels = [CELLS[i] for i in ORDER]
        plot_confusion_matrix(results['confusion_matrix'], labels,
                              f'Confusion Matrix - Run {i + 1}',
                              f'confusion_matrix_run{i + 1}.png')

        print(f"Model {i + 1} evaluation completed in: {time() - t00:.2f}s")

    # 计算统计结果
    if all_results:
        # 提取所有指标
        accuracies = [r['accuracy'] for r in all_results]
        precisions = [r['precision'] for r in all_results]
        recalls = [r['recall'] for r in all_results]
        f1_scores = [r['f1_score'] for r in all_results]

        # 计算平均值和标准差
        stats = {
            'accuracy': {'mean': np.mean(accuracies), 'std': np.std(accuracies)},
            'precision': {'mean': np.mean(precisions), 'std': np.std(precisions)},
            'recall': {'mean': np.mean(recalls), 'std': np.std(recalls)},
            'f1_score': {'mean': np.mean(f1_scores), 'std': np.std(f1_scores)}
        }

        # 保存详细结果到文件
        with open('test_results.txt', 'w') as f:
            f.write("Model Evaluation Results\n")
            f.write("=" * 50 + "\n\n")

            # 写入每个模型的详细结果
            f.write("Individual Model Results:\n")
            f.write("-" * 30 + "\n")
            f.write("Model\tAccuracy\tPrecision\tRecall\tF1-Score\n")
            for i, result in enumerate(all_results):
                f.write(f"Run_{i + 1}\t{result['accuracy']:.4f}\t\t{result['precision']:.4f}\t\t"
                        f"{result['recall']:.4f}\t{result['f1_score']:.4f}\n")

            # 写入统计结果
            f.write("\nStatistical Summary (Mean ± Std):\n")
            f.write("-" * 40 + "\n")
            f.write(f"Accuracy:  {stats['accuracy']['mean']:.4f} ± {stats['accuracy']['std']:.4f}\n")
            f.write(f"Precision: {stats['precision']['mean']:.4f} ± {stats['precision']['std']:.4f}\n")
            f.write(f"Recall:    {stats['recall']['mean']:.4f} ± {stats['recall']['std']:.4f}\n")
            f.write(f"F1-Score:  {stats['f1_score']['mean']:.4f} ± {stats['f1_score']['std']:.4f}\n")

            # 写入详细分类报告（使用第一个模型作为示例）
            if all_results:
                f.write("\nDetailed Classification Report (Run 1 as example):\n")
                f.write("-" * 50 + "\n")
                report_df = pd.DataFrame(all_results[0]['classification_report']).transpose()
                f.write(report_df.to_string())

        # 打印最终统计结果
        print("\n" + "=" * 60)
        print("FINAL STATISTICAL SUMMARY:")
        print("=" * 60)
        print(f"Accuracy:  {stats['accuracy']['mean']:.4f} ± {stats['accuracy']['std']:.4f}")
        print(f"Precision: {stats['precision']['mean']:.4f} ± {stats['precision']['std']:.4f}")
        print(f"Recall:    {stats['recall']['mean']:.4f} ± {stats['recall']['std']:.4f}")
        print(f"F1-Score:  {stats['f1_score']['mean']:.4f} ± {stats['f1_score']['std']:.4f}")
        print("=" * 60)

        print(f"\nResults saved to 'test_results.txt'")
    else:
        print("No models were successfully evaluated!")

    print(f'\nTotal evaluation completed in: {time() - t00:.2f}s')