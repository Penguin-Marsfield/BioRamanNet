# 5 cell
ORDER = [0, 1, 2, 3]

EVPS = {}
EVPS[0] = "Normal"
EVPS[1] = "THP-1"
EVPS[2] = "DU-145"
EVPS[3] = "COLO-205"
