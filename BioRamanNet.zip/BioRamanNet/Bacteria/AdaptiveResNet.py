import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from AdaptiveConv1d import AdaptiveConv1d


class MultiScaleConv1d(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(MultiScaleConv1d, self).__init__()
        self.conv1 = AdaptiveConv1d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv2 = AdaptiveConv1d(in_channels, out_channels, kernel_size=5, padding=2)
        self.conv3 = AdaptiveConv1d(in_channels, out_channels, kernel_size=7, padding=3)
        self.bn = nn.BatchNorm1d(out_channels)

    def forward(self, x):
        out1 = self.conv1(x)
        out2 = self.conv2(x)
        out3 = self.conv3(x)
        out = out1 + out2 + out3
        return F.relu(self.bn(out))


class SEBlock(nn.Module):
    def __init__(self, channels, reduction=16):
        super(SEBlock, self).__init__()
        self.global_avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(channels, channels // reduction, bias=False)
        self.fc2 = nn.Linear(channels // reduction, channels, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        batch, channels, _ = x.size()
        y = self.global_avg_pool(x).view(batch, channels)
        y = F.relu(self.fc1(y))
        y = self.sigmoid(self.fc2(y)).view(batch, channels, 1)
        return x * y


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, dropout_rate=0.3):
        super(ResidualBlock, self).__init__()
        self.multi_scale_conv = MultiScaleConv1d(in_channels, out_channels)
        self.se_block = SEBlock(out_channels)
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.dropout = nn.Dropout(p=dropout_rate)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                AdaptiveConv1d(in_channels, out_channels, kernel_size=1, padding=0),
                nn.BatchNorm1d(out_channels))

    def forward(self, x):
        out = self.multi_scale_conv(x)
        out = self.se_block(out)
        out = self.bn1(out)
        out = self.dropout(out)
        out += self.shortcut(x)
        return F.relu(out)


class ResNet(nn.Module):
    def __init__(self, hidden_sizes, num_blocks, input_dim, in_channels, n_classes):
        super(ResNet, self).__init__()
        assert len(num_blocks) == len(hidden_sizes)
        self.input_dim = input_dim
        self.in_channels = in_channels
        self.n_classes = n_classes

        self.conv1 = AdaptiveConv1d(1, self.in_channels, kernel_size=5, padding=2)
        self.bn1 = nn.BatchNorm1d(self.in_channels)

        layers = []
        strides = [1] + [2] * (len(hidden_sizes) - 1)
        for idx, hidden_size in enumerate(hidden_sizes):
            layers.append(self._make_layer(hidden_size, num_blocks[idx], stride=strides[idx]))
        self.encoder = nn.Sequential(*layers)

        self.z_dim = self._get_encoding_size()
        self.linear = nn.Sequential(
            nn.LayerNorm(self.z_dim),
            nn.Linear(self.z_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(128, self.n_classes)
        )

    def encode(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.encoder(x)
        z = x.view(x.size(0), -1)
        return z

    def forward(self, x):
        z = self.encode(x)
        return self.linear(z)

    def _make_layer(self, out_channels, num_blocks, stride=1):
        strides = [stride] + [1] * (num_blocks - 1)
        blocks = []
        for stride in strides:
            blocks.append(ResidualBlock(self.in_channels, out_channels, stride=stride))
            self.in_channels = out_channels
        return nn.Sequential(*blocks)

    def _get_encoding_size(self):
        temp = torch.rand(1, 1, self.input_dim)
        z = self.encode(temp)
        return z.data.size(1)

# # 参数设置
# layers = 6
# hidden_size = 100
# block_size = 2
# hidden_sizes = [hidden_size] * layers
# num_blocks = [block_size] * layers
# input_dim = 3131
# in_channels = 64
# n_classes = 12