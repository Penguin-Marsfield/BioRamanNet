import math
import torch
import torch.nn as nn


class AdaptiveConv1d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, padding=1):
        super(AdaptiveConv1d, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.padding = padding
        self.weight = nn.Parameter(torch.Tensor(out_channels, in_channels, kernel_size))
        self.bias = nn.Parameter(torch.Tensor(out_channels))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            fan_in = self.in_channels * self.kernel_size
            bound = 1 / math.sqrt(fan_in)
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x):
        weight_1 = self.weight.sum(dim=[2]).unsqueeze(-1)
        x_1 = nn.functional.conv1d(x, weight_1, bias=None, stride=1, padding=0)
        weight_3 = self.weight
        x_3 = nn.functional.conv1d(x, weight_3, bias=None, stride=1, padding=self.padding)
        x_out = x_1 + x_3 + self.bias.view(1, -1, 1).expand_as(x_1)
        return x_out


